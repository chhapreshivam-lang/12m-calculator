const rateData = {
  // ... (paste your rateData object here)
};
const blackoutDates = [
  // ... (paste your blackoutDates array here)
];

function isWeekend(date) {
  const day = date.getDay();
  return day === 5 || day === 6; // Friday & Saturday
}
function getMonthKey(date) {
  const monthAbbr = date.toLocaleString('en-US', { month: 'short' });
  const yearTwoDigit = date.getFullYear().toString().slice(-2);
  return `${monthAbbr}-${yearTwoDigit}`;
}
function getRateGroup(rooms) {
  if (rooms >= 1 && rooms <= 8) return '1 to 8';
  if (rooms >= 9 && rooms <= 17) return '9 to 17';
  if (rooms >= 18 && rooms <= 25) return '18 to 25';
  return null;
}
function isBlackout(date) {
  return blackoutDates.includes(date.toISOString().slice(0,10));
}

window.onload = function() {
  const today = new Date();
  const todayStr = today.toISOString().slice(0,10);
  const tomorrow = new Date(today);
  tomorrow.setDate(tomorrow.getDate() + 1);
  const tomorrowStr = tomorrow.toISOString().slice(0,10);

  const checkinInput = document.getElementById('checkin');
  const checkoutInput = document.getElementById('checkout');

  checkinInput.value = todayStr;
  checkoutInput.value = tomorrowStr;

  checkinInput.addEventListener('change', function() {
    const ciDate = new Date(this.value);
    let coDate = new Date(checkoutInput.value);
    if(coDate <= ciDate) {
      coDate = new Date(ciDate);
      coDate.setDate(coDate.getDate() + 1);
      checkoutInput.value = coDate.toISOString().slice(0,10);
    }
  });
};

function calculateRate() {
  const checkinInput = document.getElementById('checkin').value;
  const checkoutInput = document.getElementById('checkout').value;
  const roomsInput = parseInt(document.getElementById('rooms').value, 10);
  const resultDiv = document.getElementById('result');
  const messageDiv = document.getElementById('message');
  resultDiv.style.display = 'none';
  resultDiv.innerHTML = '';
  messageDiv.style.color = 'red';
  messageDiv.innerHTML = '';

  if (!checkinInput || !checkoutInput || isNaN(roomsInput)) {
    messageDiv.innerHTML = "Please fill all fields correctly.";
    return;
  }

  const checkIn = new Date(checkinInput);
  const checkOut = new Date(checkoutInput);

  if (checkOut <= checkIn) {
    messageDiv.innerHTML = "Check-out date must be after check-in date.";
    return;
  }

  if (roomsInput > 25) {
    messageDiv.innerHTML = "Discuss with revenue team: Rooms requested exceed 25.";
    return;
  }

  const rateGroup = getRateGroup(roomsInput);
  if (!rateGroup) {
    messageDiv.innerHTML = "Rooms requested outside supported range (1-25).";
    return;
  }

  let totalRate = 0;
  let totalNights = Math.round((checkOut - checkIn) / (1000 * 60 * 60 * 24));
  let weekendsCount = 0;
  let weekdaysCount = 0;

  let currDate = new Date(checkIn);
  for (let i = 0; i < totalNights; i++) {
    if (isBlackout(currDate)) {
      messageDiv.innerHTML = "Black out date(s) detected: Discuss with revenue team.";
      return;
    }
    const monthKey = getMonthKey(currDate);
    const dayType = isWeekend(currDate) ? 'Weekend' : 'Weekday';
    if (dayType === 'Weekend') weekendsCount++;
    else weekdaysCount++;
    const rate = rateData[rateGroup][monthKey]?.[dayType] || 0;
    totalRate += rate * roomsInput;
    currDate.setDate(currDate.getDate() + 1);
  }

  const avgRate = totalRate / totalNights / roomsInput;

  messageDiv.style.color = 'green';
  messageDiv.innerHTML = `Weekdays: ${weekdaysCount}, Weekends: ${weekendsCount}`;
  resultDiv.style.display = 'block';
  resultDiv.innerHTML =
    `<p><strong>Total rate for ${roomsInput} room(s) from ${checkinInput} to ${checkoutInput}:</strong> $${totalRate.toFixed(2)}</p>` +
    `<p><strong>Average daily rate per room:</strong> $${avgRate.toFixed(2)}</p>`;
}